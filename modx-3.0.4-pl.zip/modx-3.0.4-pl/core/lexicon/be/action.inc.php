<?php
/**
 * Action English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['action'] = 'Дзеянне';
$_lang['action_desc'] = 'Дзеянні з\'яўляюцца абстракцыямі кантролераў MODX. Яны могуць быць выкарыстаны для стварэння карыстальнiцкiх старонак мэнэджара, а таксама для рэарганізацыi галоўнага меню мэнэджара MODX.';
$_lang['action_err_ns'] = 'Ніякіх дзеянняў не пазначана!';
$_lang['actions'] = 'Дзеянні';
